from __future__ import annotations

from datetime import datetime, timezone

import pandas as pd
import yfinance as yf

from backend.data.base import DataResult, MarketDataProvider, ProviderError

# yfinance period strings the UI is allowed to request.
VALID_PERIODS = {"1d", "5d", "1mo", "3mo", "6mo", "1y", "3y", "5y", "max"}


class YFinanceProvider(MarketDataProvider):
    """Primary market data source. Free, no API key, but data is
    delayed (typically ~15 minutes) and occasionally rate-limited."""

    name = "yfinance"

    def get_quote(self, ticker: str) -> DataResult:
        # `fast_info` hits a Yahoo endpoint that's proven flaky/rate-limited
        # in practice. Recent daily bars from `history()` are far more
        # reliable, so we derive the "quote" from the latest close instead.
        # This is honestly labeled end-of-day/delayed rather than real-time.
        try:
            t = yf.Ticker(ticker)
            hist = t.history(period="5d", interval="1d", auto_adjust=False)
            if hist is None or hist.empty:
                raise ProviderError(f"No recent price data returned for {ticker}")
            hist = hist.dropna(subset=["Close"])
            if hist.empty:
                raise ProviderError(f"No valid recent closes for {ticker}")

            last = hist.iloc[-1]
            prev = hist.iloc[-2] if len(hist) >= 2 else None

            market_cap = None
            try:
                market_cap = t.fast_info.get("market_cap")
            except Exception:  # noqa: BLE001 - market cap is a nice-to-have, never fatal
                pass

            data = {
                "ticker": ticker.upper(),
                "price": float(last["Close"]),
                "previous_close": float(prev["Close"]) if prev is not None else None,
                "day_high": float(last["High"]),
                "day_low": float(last["Low"]),
                "volume": int(last["Volume"]) if pd.notna(last["Volume"]) else None,
                "market_cap": market_cap,
                "currency": "USD",
            }
            return DataResult(
                data=data,
                source=self.name,
                fetched_at=datetime.now(timezone.utc),
                timeliness="end_of_day",
            )
        except Exception as exc:  # noqa: BLE001 - provider boundary, must not crash caller
            return DataResult(
                data=None,
                source=self.name,
                fetched_at=datetime.now(timezone.utc),
                timeliness="end_of_day",
                success=False,
                error=str(exc),
                quality="ERROR",
            )

    def get_historical(self, ticker: str, period: str, interval: str = "1d") -> DataResult:
        if period not in VALID_PERIODS:
            period = "1y"
        try:
            t = yf.Ticker(ticker)
            hist = t.history(period=period, interval=interval, auto_adjust=False)
            if hist is None or hist.empty:
                raise ProviderError(f"No historical data returned for {ticker}")

            hist = hist.reset_index()
            date_col = "Date" if "Date" in hist.columns else "Datetime"
            df = pd.DataFrame({
                "date": pd.to_datetime(hist[date_col]).dt.strftime("%Y-%m-%d"),
                "open": hist["Open"],
                "high": hist["High"],
                "low": hist["Low"],
                "close": hist["Close"],
                "adj_close": hist["Adj Close"] if "Adj Close" in hist.columns else hist["Close"],
                "volume": hist["Volume"],
            })
            return DataResult(
                data=df,
                source=self.name,
                fetched_at=datetime.now(timezone.utc),
                timeliness="end_of_day" if interval == "1d" else "delayed_15m",
            )
        except Exception as exc:  # noqa: BLE001
            return DataResult(
                data=None,
                source=self.name,
                fetched_at=datetime.now(timezone.utc),
                timeliness="end_of_day",
                success=False,
                error=str(exc),
                quality="ERROR",
            )

    def search(self, query: str) -> DataResult:
        try:
            results = yf.Search(query, max_results=10).quotes
            data = [
                {
                    "ticker": r.get("symbol"),
                    "name": r.get("shortname") or r.get("longname"),
                    "exchange": r.get("exchange"),
                    "type": r.get("quoteType"),
                }
                for r in results
                if r.get("symbol")
            ]
            return DataResult(
                data=data,
                source=self.name,
                fetched_at=datetime.now(timezone.utc),
                timeliness="cached",
            )
        except Exception as exc:  # noqa: BLE001
            return DataResult(
                data=[],
                source=self.name,
                fetched_at=datetime.now(timezone.utc),
                timeliness="cached",
                success=False,
                error=str(exc),
                quality="ERROR",
            )
