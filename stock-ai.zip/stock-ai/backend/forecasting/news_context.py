"""
Live news context for predictions — deliberately POST-HOC, never a
trained feature.

Why not a real feature: training the model on news sentiment would
require knowing what the sentiment was on every historical date going
back years, which we don't have (no point-in-time news archive — our
providers only return *recent* headlines). Faking it by applying
today's sentiment to historical training rows would be a serious form
of look-ahead bias: the model would be trained as if it "knew" news
sentiment on days it couldn't actually have known.

What this does instead: fetches CURRENT news only, aggregates it into
a single directional read, and compares that against what the
(purely price/technical-trained) ensemble already concluded. This
never changes the model's prediction, confidence, or weighting — it's
an independent, second opinion presented alongside the model's own
read, exactly the way a human analyst would cross-check a technical
signal against the headlines before acting on it.

One adaptation genuinely worth having, though: the "recent N articles"
window can span a much wider calendar gap right after a weekend or
holiday than on an ordinary trading day — Monday morning's "10 most
recent articles" might stretch back through Saturday and Sunday, while
Tuesday's covers barely more than one day. Averaging every article in
that window equally would let a single stale Saturday rumor count the
same as this morning's actual earnings report. Since every article
already carries a real publish timestamp, this recency-weights the
impact score (more recent = more weight) and is transparent in the
summary about how wide a window is actually being averaged over —
this is a live-only adaptation of the same underlying idea, not the
historical-training version, which still isn't possible without a
point-in-time archive we don't have.
"""
from __future__ import annotations

import math
from datetime import datetime, timezone
from typing import Optional

RECENCY_HALF_LIFE_HOURS = 18  # an article twice this old counts for roughly half as much


def get_news_context(ticker: str, ensemble_direction: str, news_service=None, fundamentals_service=None) -> dict:
    """Returns {available, article_count, avg_impact_score, news_direction,
    agrees_with_model, summary}. Never raises — a news fetch failure
    just means unavailable context, not a broken prediction."""
    if news_service is None:
        from backend.news.service import news_service as default_news_service
        news_service = default_news_service

    # Resolve the company name so the news search isn't limited to
    # headlines that literally contain the ticker symbol — a real gap
    # found via testing: "NVDA" search misses articles that only say
    # "NVIDIA", which is most of them. Best-effort; falls back to a
    # ticker-only search if fundamentals lookup fails for any reason.
    company_name = None
    try:
        if fundamentals_service is None:
            from backend.fundamentals.service import fundamentals_service as default_fundamentals_service
            fundamentals_service = default_fundamentals_service
        fund_result = fundamentals_service.get_fundamentals(ticker)
        if fund_result.success and fund_result.data:
            company_name = fund_result.data.get("short_name") or fund_result.data.get("long_name")
    except Exception:  # noqa: BLE001
        pass  # ticker-only search is a fine fallback, not worth failing the whole prediction over

    try:
        result = news_service.get_analyzed_news(ticker, limit=10, company_name=company_name)
    except Exception:  # noqa: BLE001
        return {"available": False, "reason": "News fetch failed."}

    if not result.success or not result.data:
        return {"available": False, "reason": "No recent news available for this ticker."}

    items = result.data
    scored_items = [item for item in items if "impact_score" in item]
    if not scored_items:
        return {"available": False, "reason": "News found but no analyzable impact scores."}

    now = datetime.now(timezone.utc)
    weighted_sum, weight_total = 0.0, 0.0
    parsed_dates: list[datetime] = []
    for item in scored_items:
        age_hours = None
        published_at = item.get("published_at")
        if published_at:
            try:
                published_dt = datetime.fromisoformat(published_at)
                if published_dt.tzinfo is None:
                    published_dt = published_dt.replace(tzinfo=timezone.utc)
                age_hours = max((now - published_dt).total_seconds() / 3600, 0)
                parsed_dates.append(published_dt)
            except (ValueError, TypeError):
                age_hours = None
        # An article with no usable timestamp still counts, just at
        # neutral (not-recency-boosted, not-penalized) weight, rather
        # than being dropped — a missing date isn't a reason to throw
        # away a real, already-analyzed article.
        weight = 0.5 ** (age_hours / RECENCY_HALF_LIFE_HOURS) if age_hours is not None else 0.5
        weighted_sum += item["impact_score"] * weight
        weight_total += weight

    avg_impact = weighted_sum / weight_total if weight_total > 0 else 0.0

    # Transparency about the actual window being averaged over — this
    # is the part that matters more right after a weekend/holiday than
    # on an ordinary day.
    coverage_note = ""
    if len(parsed_dates) >= 2:
        span_hours = (max(parsed_dates) - min(parsed_dates)).total_seconds() / 3600
        if span_hours > 30:  # meaningfully wider than a single trading day
            span_days = round(span_hours / 24, 1)
            coverage_note = f" (spans about {span_days} days, likely including a weekend or holiday gap)"

    if avg_impact >= 15:
        news_direction = "bullish"
    elif avg_impact <= -15:
        news_direction = "bearish"
    else:
        news_direction = "neutral"

    agrees_with_model: Optional[bool]
    if ensemble_direction == "neutral" or news_direction == "neutral":
        agrees_with_model = None  # not a meaningful comparison either way
    else:
        agrees_with_model = (ensemble_direction == news_direction)

    summary = (
        f"{len(scored_items)} recent article(s), recency-weighted, average {avg_impact:+.0f} impact "
        f"(scale -100 to +100){coverage_note} — reads {news_direction}."
    )
    if agrees_with_model is False:
        summary += f" This runs counter to the model's own {ensemble_direction} read — worth a second look."
    elif agrees_with_model is True:
        summary += f" This agrees with the model's {ensemble_direction} read."

    return {
        "available": True,
        "article_count": len(scored_items),
        "avg_impact_score": round(avg_impact, 1),
        "news_direction": news_direction,
        "agrees_with_model": agrees_with_model,
        "summary": summary,
    }
